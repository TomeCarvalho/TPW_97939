export class Author {
  num: number | undefined
  name: string | undefined
  email: string | undefined
}
